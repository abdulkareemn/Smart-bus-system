const $=id=>document.getElementById(id);let state={};
async function api(path,opts={}){const r=await fetch(path,{headers:{"Content-Type":"application/json"},...opts});const d=await r.json();if(!r.ok)throw Error(d.error||"Request failed");return d}
function badge(s){return `<span class="badge ${s.toLowerCase()}">${s}</span>`}
async function refresh(){try{
const [d,b,r,o,recs]=await Promise.all(["/api/dashboard","/api/buses","/api/routes","/api/occupancy","/api/recommendations"].map(api));state={d,b,r,o,recs};
$("total").textContent=d.total_buses;$("available").textContent=d.available_buses;$("routesnum").textContent=d.routes_monitored;$("risk").textContent=d.high_risk_routes;
$("predictions").innerHTML=d.predictions.map(p=>`<article class="prediction"><div class="row"><b>${p.route_name}</b>${badge(p.crowd_level)}</div><div class="pct">${p.predicted_occupancy}% <small>predicted occupancy</small></div><div class="bar"><i style="width:${Math.min(100,p.predicted_occupancy)}%"></i></div><div class="sub"><span>${p.predicted_passengers} predicted passengers</span><span>Capacity ${p.capacity}</span></div><div class="action">${p.recommendation}</div></article>`).join("");
$("bustable").innerHTML=b.map(x=>`<tr><td><b>${x.id}</b></td><td>${x.registration}</td><td>${r.find(y=>y.id===x.route_id)?.name||x.route_id}</td><td>${x.capacity} seats</td><td>${x.available?badge("Low"):badge("Moderate")}</td></tr>`).join("");
$("routetable").innerHTML=r.map(x=>`<tr><td>${x.name}</td><td>${x.distance_km} km</td><td>${x.travel_minutes} min</td><td>${x.historical_demand}</td></tr>`).join("");
$("busselect").innerHTML=b.map(x=>`<option value="${x.id}">${x.id} · ${x.registration}</option>`).join("");
$("occtable").innerHTML=[...o].reverse().map(x=>`<tr><td>${x.id}</td><td>${x.bus_id}</td><td>${x.route_id}</td><td>${x.passengers}</td><td>${x.recorded_at}</td></tr>`).join("");
$("reclist").innerHTML=recs.length?[...recs].reverse().map(x=>`<article class="rec"><div><b>${x.recommendation}</b><small>${x.id} · ${x.status}</small></div><button ${x.status==="Approved"?"disabled":""} onclick="approve('${x.id}')">${x.status==="Approved"?"Approved":"Approve"}</button></article>`).join(""):'<article class="rec">No saved recommendations yet. Use the API to create one.</article>';
}catch(e){alert("Unable to load data: "+e.message)}}
document.querySelectorAll(".nav").forEach(btn=>btn.onclick=()=>{document.querySelectorAll(".nav").forEach(x=>x.classList.remove("active"));btn.classList.add("active");document.querySelectorAll(".view").forEach(x=>x.classList.add("hide"));$(btn.dataset.view).classList.remove("hide");$("title").textContent=btn.textContent.trim().replace(/^[▦⌁◉✧]\\s*/,"")});
$("form").onsubmit=async e=>{e.preventDefault();$("message").textContent="Saving…";try{await api("/api/occupancy",{method:"POST",body:JSON.stringify({bus_id:$("busselect").value,passengers:Number($("passengers").value)})});$("message").textContent="Saved. Dashboard recalculated.";$("passengers").value="";await refresh()}catch(err){$("message").textContent=err.message}};
async function approve(id){try{await api(`/api/recommendations/${id}/approve`,{method:"POST",body:"{}"});await refresh()}catch(e){alert(e.message)}}
window.refresh=refresh;window.approve=approve;refresh();
