# TransitAI – AI-Based Smart College Bus System

Runnable academic prototype for passenger occupancy monitoring, baseline demand forecasting, overcrowding alerts and human-reviewed recommendations.

## Run
Requires Python 3.9+. No third-party Python packages are required.
1. Extract this ZIP.
2. Open terminal inside `TransitAI_Complete_Project`.
3. Run `python app.py`.
4. Open `http://127.0.0.1:8000`.
5. Stop with Ctrl+C.

## Tests
`python -m unittest discover -s tests -v`

## Forecast method
`predicted_passengers = round(0.65 * current_passengers + 0.35 * historical_route_demand)`
Predicted occupancy is predicted passengers divided by bus capacity times 100. Low <65%; Moderate 65–84%; High 85–99%; Critical >=100%.

This is a transparent rule-based baseline, **not a trained ML model**. Sample records are illustrative. No live GPS, traffic, camera counting, student login, production ML or real bus dispatch is connected. Approval only changes a demo record status. This is for local academic demonstration, not production/safety-critical use.
