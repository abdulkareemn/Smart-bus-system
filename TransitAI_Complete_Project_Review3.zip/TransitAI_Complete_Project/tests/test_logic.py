import sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from app import occupancy_percent,predict
class LogicTests(unittest.TestCase):
 def test_percent(self): self.assertEqual(occupancy_percent(25,50),50)
 def test_zero_capacity(self): self.assertEqual(occupancy_percent(10,0),0)
 def test_prediction(self):
  p=predict({"id":"R","name":"Route","historical_demand":40},{"capacity":50},40)
  self.assertEqual(p["predicted_passengers"],40);self.assertEqual(p["predicted_occupancy"],80);self.assertEqual(p["crowd_level"],"Moderate")
 def test_critical(self): self.assertEqual(predict({"id":"R","name":"Route","historical_demand":100},{"capacity":50},100)["crowd_level"],"Critical")
if __name__=="__main__": unittest.main()
