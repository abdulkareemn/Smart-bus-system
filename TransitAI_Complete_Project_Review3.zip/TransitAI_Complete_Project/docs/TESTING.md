# Testing
Run automated unit tests: `python -m unittest discover -s tests -v`.

Automated cases cover occupancy percentage, zero-capacity handling, expected baseline prediction and critical crowd classification.

Manual validation checklist: (1) Overview loads metrics. (2) Bus and route tables load. (3) Add occupancy using a valid bus and non-negative integer. (4) Confirm record appears in history. (5) Confirm forecast refreshes. (6) Submit a negative count or unknown bus through the API and confirm HTTP 400. (7) Create a recommendation with POST, then approve it.

Error handling: invalid JSON/values return 400; unknown paths return 404; unexpected server errors return 500. Manual checklist items must be executed before claiming they passed.
