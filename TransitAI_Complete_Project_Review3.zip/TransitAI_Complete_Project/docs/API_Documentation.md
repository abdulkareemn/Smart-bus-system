# API documentation
Base URL: `http://127.0.0.1:8000` (JSON responses).

| Endpoint | Method | Purpose |
|---|---|---|
| `/api/health` | GET | Health check |
| `/api/dashboard` | GET | Summary and forecasts |
| `/api/buses` | GET | Bus directory |
| `/api/routes` | GET | Route directory |
| `/api/occupancy` | GET | Recent occupancy records |
| `/api/predictions` | GET | Route predictions |
| `/api/recommendations` | GET | Saved recommendations |
| `/api/occupancy` | POST | Add occupancy: `{"bus_id":"BUS-101","passengers":42}` |
| `/api/recommendations` | POST | Create: `{"recommendation":"Review bus allocation"}` |
| `/api/recommendations/{id}/approve` | POST | Approve recommendation |

Validation errors return HTTP 400; unknown endpoints return HTTP 404. The prototype stores data in a local JSON file.
