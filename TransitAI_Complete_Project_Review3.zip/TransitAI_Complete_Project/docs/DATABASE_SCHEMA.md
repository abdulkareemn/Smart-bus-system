# Logical data schema
The prototype uses `data/store.json` with four arrays.

- **buses:** id, registration, capacity, available, route_id.
- **routes:** id, name, distance_km, travel_minutes, historical_demand.
- **occupancy:** id, bus_id, route_id, passengers, recorded_at.
- **recommendations:** id, recommendation, status, created_at.

Production migration should use a transactional database, authentication, role-based access, audit logs and referential constraints.
