from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlparse
from datetime import datetime
import json, threading, uuid
ROOT=Path(__file__).resolve().parent
DB=ROOT/"data"/"store.json"
LOCK=threading.Lock()
SEED={"buses":[{"id":"BUS-101","registration":"TN 37 AB 1101","capacity":50,"available":True,"route_id":"R-A"},{"id":"BUS-102","registration":"TN 37 AB 1102","capacity":40,"available":True,"route_id":"R-B"},{"id":"BUS-103","registration":"TN 37 AB 1103","capacity":50,"available":False,"route_id":"R-C"}],
"routes":[{"id":"R-A","name":"Gandhipuram – Campus","distance_km":12,"travel_minutes":35,"historical_demand":46},{"id":"R-B","name":"Ukkadam – Campus","distance_km":9,"travel_minutes":28,"historical_demand":25},{"id":"R-C","name":"Peelamedu – Campus","distance_km":7,"travel_minutes":22,"historical_demand":38}],
"occupancy":[{"id":"O-1","bus_id":"BUS-101","route_id":"R-A","passengers":46,"recorded_at":"2026-11-02 08:00"},{"id":"O-2","bus_id":"BUS-102","route_id":"R-B","passengers":18,"recorded_at":"2026-11-02 08:00"},{"id":"O-3","bus_id":"BUS-103","route_id":"R-C","passengers":39,"recorded_at":"2026-11-02 08:00"}],"recommendations":[]}
def load():
    if not DB.exists(): DB.write_text(json.dumps(SEED,indent=2))
    return json.loads(DB.read_text())
def save(s): DB.write_text(json.dumps(s,indent=2))
def occupancy_percent(n,c): return round(n/c*100) if c else 0
def predict(route,bus,current):
    demand=round(.65*max(0,int(current))+.35*max(0,int(route["historical_demand"])))
    pct=occupancy_percent(demand,bus["capacity"])
    level="Critical" if pct>=100 else "High" if pct>=85 else "Moderate" if pct>=65 else "Low"
    action="Deploy an available bus or split passenger load" if pct>=100 else "Review additional bus allocation" if pct>=85 else "Monitor occupancy" if pct>=65 else "No immediate action required"
    return {"route_id":route["id"],"route_name":route["name"],"current_passengers":current,"predicted_passengers":demand,"capacity":bus["capacity"],"predicted_occupancy":pct,"crowd_level":level,"recommendation":action}
def dashboard(s):
    ps=[]
    for r in s["routes"]:
        b=next((x for x in s["buses"] if x["route_id"]==r["id"]),None)
        o=next((x for x in reversed(s["occupancy"]) if x["route_id"]==r["id"]),None)
        if b and o: ps.append(predict(r,b,o["passengers"]))
    return {"total_buses":len(s["buses"]),"available_buses":sum(b["available"] for b in s["buses"]),"routes_monitored":len(s["routes"]),"high_risk_routes":sum(p["predicted_occupancy"]>=85 for p in ps),"predictions":ps}
class H(SimpleHTTPRequestHandler):
    def __init__(self,*a,**kw): super().__init__(*a,directory=str(ROOT/"static"),**kw)
    def out(self,obj,status=200):
        raw=json.dumps(obj).encode(); self.send_response(status); self.send_header("Content-Type","application/json"); self.send_header("Content-Length",str(len(raw))); self.send_header("Cache-Control","no-store"); self.end_headers(); self.wfile.write(raw)
    def body(self):
        n=int(self.headers.get("Content-Length",0))
        if n>100000: raise ValueError()
        return json.loads(self.rfile.read(n) or b"{}")
    def do_GET(self):
        p=urlparse(self.path).path
        if p=="/": self.path="/index.html"; return super().do_GET()
        with LOCK: s=load()
        endpoints={"/api/health":{"status":"ok","service":"TransitAI"},"/api/dashboard":dashboard(s),"/api/buses":s["buses"],"/api/routes":s["routes"],"/api/occupancy":s["occupancy"][-50:],"/api/predictions":dashboard(s)["predictions"],"/api/recommendations":s["recommendations"]}
        return self.out(endpoints[p]) if p in endpoints else self.out({"error":"Endpoint not found"},404)
    def do_POST(self):
        p=urlparse(self.path).path
        try:
            b=self.body()
            with LOCK:
                s=load()
                if p=="/api/occupancy":
                    bus=next((x for x in s["buses"] if x["id"]==b.get("bus_id")),None); n=b.get("passengers")
                    if not bus: return self.out({"error":"Unknown bus_id"},400)
                    if type(n)!=int or n<0 or n>bus["capacity"]*2: return self.out({"error":"Passenger count must be a non-negative integer within the validation limit"},400)
                    row={"id":"O-"+uuid.uuid4().hex[:8],"bus_id":bus["id"],"route_id":bus["route_id"],"passengers":n,"recorded_at":datetime.now().isoformat(timespec="seconds")}
                    s["occupancy"].append(row); save(s); return self.out(row,201)
                if p=="/api/recommendations":
                    value=b.get("recommendation")
                    if not isinstance(value,str) or not value.strip(): return self.out({"error":"recommendation is required"},400)
                    row={"id":"REC-"+uuid.uuid4().hex[:8],"recommendation":value.strip(),"status":"Pending","created_at":datetime.now().isoformat(timespec="seconds")}
                    s["recommendations"].append(row); save(s); return self.out(row,201)
                parts=p.strip("/").split("/")
                if len(parts)==4 and parts[0:2]==["api","recommendations"] and parts[3]=="approve":
                    row=next((x for x in s["recommendations"] if x["id"]==parts[2]),None)
                    if not row: return self.out({"error":"Recommendation not found"},404)
                    row["status"]="Approved"; save(s); return self.out(row)
            return self.out({"error":"Endpoint not found"},404)
        except (ValueError,json.JSONDecodeError): return self.out({"error":"Invalid JSON request"},400)
        except Exception: return self.out({"error":"Internal server error"},500)
if __name__=="__main__":
    print("TransitAI: http://127.0.0.1:8000")
    ThreadingHTTPServer(("127.0.0.1",8000),H).serve_forever()
